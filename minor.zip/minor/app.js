const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/course_registration', { useNewUrlParser: true, useUnifiedTopology: true });

// Define the Registration model
const Registration = require('./models/Registration');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set the view engine to ejs
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
    res.render('register');
});

app.post('/submit_registration', async (req, res) => {
    const { firstName, lastName, email, course } = req.body;
    const newRegistration = new Registration({ firstName, lastName, email, course });
    await newRegistration.save();
    res.render('register', { errorMessage: 'Registeration Done Sucessfully...' });
});

app.get('/admin', async (req, res) => {
    const registrations = await Registration.find();
    res.render('admin', { registrations });
});

app.post('/search', async (req, res) => {
    const { firstName } = req.body;
    const registrations = await Registration.find({ firstName: new RegExp(firstName, 'i') });
    res.render('admin', { registrations });
});

app.get('/edit/:id', async (req, res) => {
    const registration = await Registration.findById(req.params.id);
    res.render('edit', { registration });
});

app.post('/edit/:id', async (req, res) => {
    const { email, course } = req.body;
    await Registration.findByIdAndUpdate(req.params.id, { email, course });
    res.redirect('/admin');
});

app.get('/add', (req, res) => {
    res.render('add');
});

app.post('/add', async (req, res) => {
    const { firstName, lastName, email, course } = req.body;
    const newRegistration = new Registration({ firstName, lastName, email, course });
    await newRegistration.save();
    res.redirect('/admin');
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
